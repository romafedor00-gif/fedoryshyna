// Basic interactions: copy email & simple form handling
document.addEventListener('DOMContentLoaded', function(){
  const copyBtn = document.getElementById('copyEmailBtn');
  const emailLink = document.getElementById('email-link').textContent.trim();
  copyBtn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(emailLink);
      copyBtn.textContent = 'Скопійовано!';
      setTimeout(()=> copyBtn.textContent = 'Копіювати', 1800);
    } catch (err) {
      alert('Не вдалося скопіювати email. Скопіюйте вручну.');
    }
  });

  // contact form simple handler (uses mailto:)
  const form = document.getElementById('contactForm');
  form.addEventListener('submit', function(e){
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const message = document.getElementById('message').value.trim();
    if(!name || !message){
      alert('Будь ласка, заповніть всі поля.');
      return;
    }
    const subject = encodeURIComponent('Повідомлення з сайту від ' + name);
    const body = encodeURIComponent(message + '\n\nІмʼя: ' + name);
    // open user's mail client
    window.location.href = `mailto:annaparfonovaaa@gmail.com?subject=${subject}&body=${body}`;
  });
});
